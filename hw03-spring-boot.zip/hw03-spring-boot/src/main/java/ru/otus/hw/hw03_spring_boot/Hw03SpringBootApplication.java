package ru.otus.hw.hw03_spring_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hw03SpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Hw03SpringBootApplication.class, args);
	}

}
